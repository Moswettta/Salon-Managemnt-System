<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Sidebar</title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
   
    </style>
</head>
<body>
    <div class="sidebar">
        <h4 class="text-center">Employee Dashboard</h4>
        <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">Dashboard</a>
        <a href="appointments.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'appointments.php' ? 'active' : ''; ?>">Appointments</a>
        <a href="complete.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'complete.php' ? 'active' : ''; ?>">Served Services</a>
        <a href="profile.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">Profile</a>
        <a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Logout</a>
    </div>
</body>
</html>
