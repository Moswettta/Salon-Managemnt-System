<?php
include('config.php');
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['employee'])) {
    header("Location: ../Employee/login.php");
    exit();
}

$employeeId = $_SESSION['employee'];

// Fetch completed appointments for the logged-in employee
function fetchCompletedAppointments($conn, $employeeId) {
    $query = "SELECT * FROM appointment_completions
              WHERE employee_id = ? AND status = 'Completed'";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param('i', $employeeId);
        $stmt->execute();
        return $stmt->get_result();
    } 
    return false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Completed Appointments</title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <style>
        body { font-family: Arial, sans-serif; }
        #header { font-family: cursive; font-size: 30px; font-weight: bold; text-shadow: 2px 2px red; }
        .navbar { background-color: black; color: white; padding: 10px; }
        .sidebar { background-color: #f8f9fa; padding: 15px; }
        .sidebar a { display: block; padding: 10px; color: #000; text-decoration: none; }
        .sidebar a:hover { background-color: #e9ecef; }
    </style>
</head>
<body>
<div class="navbar">
    <div id="header">
        <a href="dashboard.php" style="color: white; text-decoration: none;">Melly's Salon Management System</a>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2 sidebar">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <div class="container-fluid" style="text-align: center; margin-bottom: 10px;">
                <a href="appointments.php" class="btn btn-warning">Back to Appointments</a>
            </div>
            <span id="header">Completed Appointments</span>
            <table class="table table-bordered table-striped" style="color: #2C2D6E; font-family: cursive; font-weight: bold;">
                <thead>
                    <tr>
                        <th>Client Name</th>
                        <th>Service</th>
                        <th>Completion Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = fetchCompletedAppointments($conn, $employeeId);
                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>" . htmlspecialchars($row['client_name']) . "</td>
                                    <td>" . htmlspecialchars($row['service_name']) . "</td>
                                    <td>" . htmlspecialchars($row['completion_date']) . "</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>No completed appointments found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
