<?php
include('config.php');
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['employee'])) {
    header("Location: ../Employee/login.php");
    exit();
}

$employeeId = $_SESSION['employee'];

// Insert completion data
function insertCompletionRecord($conn, $appointmentId, $employeeId) {
    // Fetch client details from appointments table
    $query = "SELECT a.c_id, u.fname, u.sname, a.service_name 
              FROM appointments a 
              INNER JOIN users u ON a.c_id = u.c_id 
              WHERE a.id = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param('i', $appointmentId);
        $stmt->execute();
        $stmt->bind_result($clientId, $clientFirstName, $clientLastName, $serviceName);
        $stmt->fetch();
        $stmt->close();

        $clientName = $clientFirstName . ' ' . $clientLastName;

        // Insert into appointment_completions
        $sql = "INSERT INTO appointment_completions (appointment_id, employee_id, client_name, service_name, completion_date, status) VALUES (?, ?, ?, ?, NOW(), 'Completed')";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param('iiss', $appointmentId, $employeeId, $clientName, $serviceName);
            return $stmt->execute() ? true : $stmt->error;
        }
        return "Error preparing statement: " . $conn->error;
    }
    return "Error preparing statement: " . $conn->error;
}

// Process completion requests
if (isset($_POST['complete'])) {
    $appointmentId = $_POST['appointment_id'];
    $completionResult = insertCompletionRecord($conn, $appointmentId, $employeeId);
    echo "<div class='alert alert-success'>" . ($completionResult === true 
        ? "Appointment marked as completed and record added." 
        : "Error: $completionResult") . "</div>";
}

// Fetch appointments
function fetchAppointments($conn, $employeeId, $status = null) {
    $query = "SELECT a.*, u.fname, u.sname 
              FROM appointments a 
              INNER JOIN users u ON a.c_id = u.c_id 
              WHERE a.employee_id = ?" . ($status ? " AND a.status = ?" : "");
    if ($stmt = $conn->prepare($query)) {
        $status ? $stmt->bind_param('is', $employeeId, $status) : $stmt->bind_param('i', $employeeId);
        $stmt->execute();
        return $stmt->get_result();
    }
    return false;
}

// Check if the appointment is already completed by the employee
function isAppointmentCompletedByEmployee($conn, $appointmentId, $employeeId) {
    $query = "SELECT id FROM appointment_completions WHERE appointment_id = ? AND employee_id = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param('ii', $appointmentId, $employeeId);
        $stmt->execute();
        $stmt->store_result();
        return $stmt->num_rows > 0;
    }
    return false;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Appointments</title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <style>
        body { font-family: Arial, sans-serif; }
        #header { font-family: cursive; font-size: 30px; font-weight: bold; text-shadow: 2px 2px red; }
        .navbar { background-color: black; color: white; padding: 10px; }
        .sidebar { background-color: #f8f9fa; padding: 15px; }
        .sidebar a { display: block; padding: 10px; color: #000; text-decoration: none; }
        .sidebar a:hover { background-color: #e9ecef; }
        .completion-card { margin-top: 10px; padding: 15px; border: 1px solid #ddd; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
<div class="navbar">
    <div id="header">
        <a href="dashboard.php" style="color: white; text-decoration: none;">Melly's Salon Management System</a>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2 sidebar">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <div class="container-fluid" style="text-align: center; margin-bottom: 10px;">

            </div>
            <span id="header">Appointments</span>
            <table class="table table-bordered table-striped" style="color: #2C2D6E; font-family: cursive; font-weight: bold;">
                <thead>
                    <tr>
                        <td>Client Name</td>
                        <td>Date</td>
                        <td>Time</td>
                        <td>Service</td>
                        <td>Status</td>
                        <td colspan="3" class="text-center">Action</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = fetchAppointments($conn, $employeeId);
                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $completed = isAppointmentCompletedByEmployee($conn, $row['id'], $employeeId);
                            $actionButton = $completed ? 
                                "<button class='btn btn-secondary btn-block' disabled>Already Completed</button>" : 
                                "<form action='' method='post'>
                                    <input type='hidden' name='appointment_id' value='" . htmlspecialchars($row['id']) . "'>
                                    <button type='submit' name='complete' class='btn btn-info btn-block'>Mark as Completed</button>
                                 </form>";
                            echo "<tr>
                                    <td>" . htmlspecialchars($row['fname'] . ' ' . $row['sname']) . "</td>
                                    <td>" . htmlspecialchars($row['date']) . "</td>
                                    <td>" . htmlspecialchars($row['time']) . "</td>
                                    <td>" . htmlspecialchars($row['service_name']) . "</td>
                                    <td><span style='color:" . getStatusColor($row['status']) . "'>" . htmlspecialchars($row['status']) . "</span></td>
                                    <td>" . $actionButton . "</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>No appointments found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
function getStatusColor($status) {
    $colors = ['Pending' => 'red', 'Approved' => 'green', 'Rejected' => 'red', 'Completed' => 'blue'];
    return $colors[$status] ?? 'black';
}
?>

</body>
</html>
