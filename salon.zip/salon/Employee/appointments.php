<?php
include('config.php');
session_start();

// Check if user is logged in
if (!isset($_SESSION['employee'])) {
    header("Location: ../Employee/login.php");
    exit();
}

$employeeId = $_SESSION['employee'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Appointments</title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        #header {
            font-family: cursive;
            font-size: 30px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }
        .navbar {
            background-color: black;
            color: white;
            padding: 10px;
        }
        .sidebar {
            background-color: #f8f9fa;
            padding: 15px;
        }
        .sidebar a {
            display: block;
            padding: 10px;
            color: #000;
            text-decoration: none;
        }
        .sidebar a:hover {
            background-color: #e9ecef;
        }
    </style>
</head>
<body>
<div class="navbar">
    <div id="header">
        <a href="dashboard.php" style="color: white; text-decoration: none;">Melly's Salon Management System</a>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2 sidebar">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <div class="container-fluid" style="text-align: center; margin-bottom: 10px;">
                <a href="add_app.php" class="btn btn-warning">New Appointment</a>
            </div>
            <span id="header">Appointments</span>
            <table class="table table-bordered table-striped" style="color: #2C2D6E; font-family: cursive; font-weight: bold;">
                <thead>
                    <tr>
                        <td>Client Name</td>
                        <td>Date</td>
                        <td>Time</td>
                        <td>Service</td>
                        <td>Status</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch appointments assigned to the logged-in employee
                    $query = "SELECT a.*, u.fname, u.sname 
                              FROM appointments a 
                              INNER JOIN users u ON a.c_id = u.c_id
                              WHERE a.employee_id = ?";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param('i', $employeeId);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result) {
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['fname'] . ' ' . $row['sname']); ?></td>
                                    <td><?php echo htmlspecialchars($row['date']); ?></td>
                                    <td><?php echo htmlspecialchars($row['time']); ?></td>
                                    <td><?php echo htmlspecialchars($row['service_name']); ?></td>
                                    <td>
                                        <?php
                                        $status = htmlspecialchars($row['status']);
                                        switch ($status) {
                                            case 'Pending':
                                                echo "<span style='color:red'>Pending</span>";
                                                break;
                                            case 'Approved':
                                                echo "<span style='color:green'>Approved</span>";
                                                break;
                                            case 'Rejected':
                                                echo "<span style='color:red'>Rejected</span>";
                                                break;
                                            default:
                                                echo "<span style='color:gray'>Unknown</span>"; // Handle unknown statuses
                                                break;
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo "<tr><td colspan='5'>No appointments found.</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>Error: " . $conn->error . "</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
