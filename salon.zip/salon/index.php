<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>SMS | Login</title>
  <link rel="stylesheet" href="Assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="Assets/css/custom.css">
  <link rel="stylesheet" href="Assets/css/all.min.css">
  <script src="Assets/js/bootstrap.js"></script>
  <script src="Assets/js/jquery.min.js"></script>
  <style>
    form {
        margin-top: 30px;
    }
    #header {
        border: 1px solid red;
        border-radius: 100px;
        font-family: cursive;
        font-size: 40px;
        font-weight: bold;
        text-align: center;
        text-shadow: 2px 2px red;
    }
    .label-control {
        font-family: cursive;
        font-size: 20px;
        font-weight: bold;
    }
    #footer {
        font-family: cursive;
        font-size: 20px;
        font-weight: bold;
        text-align: center;
        text-shadow: 2px 2px red;
    }
    .signup-form {
        display: none;
    }
    .show-signup {
        display: inline-block;
    }
    /* Header Styles */
    .navbar {
        background-color: blue;
        color: black;
        padding: 10px 20px;
    }
    .navbar a {
        color: #fff;
        text-decoration: none;
        padding: 10px;
    }
    .navbar a:hover {
        background-color: #575757;
        border-radius: 5px;
    }
  </style>
  <script>
    // Function to show the sign-up form
    function showSignUpForm() {
      $('.signup-form').show();
      $('.show-signup').hide();
    }
  </script>
</head>
<body>
  <!-- Header Section -->
  <div class="navbar">
    <a href="admin">admin</a>
   <a href="Employer">Employer</a>
     <a href="Employee">Employee</a>
   
    <h1>Melly's Salon Management System</h1>
  </div>
  
  <div class="body">
    <div class="container">
      
        <?php
        // Database connection
        define("DB_HOST","localhost");
        define("DB_USER","root");
        define("DB_PASS","");
        define("DB_NAME","salon");

        $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        error_reporting(0);
        session_start();

        // Rest of your PHP code...

        // Login Form Processing
        if (isset($_POST['sub'])) {
            $name = $_POST['username'];
            $pass = sha1($_POST['password']);
            $sql = "SELECT * FROM users WHERE username='$name' AND password='$pass'";
            $query = mysqli_query($conn, $sql);
            if ($r = mysqli_fetch_array($query)) {
                $pos = $r['position'];
            }
            $count = mysqli_num_rows($query);
            if ($count == 1) {
                $_SESSION['user'] = $name;
                if ($pos == 'Receptionist') {
                    header("Location: Customer/");
                } else {
                    header("Location: Customer/");
                }
            } else {
                echo "
                <div class='alert alert-danger' id='alert'>
                <a href='#' data-dismiss='alert' class='close'>&times</a>
                <strong>Error!!!</strong>Login Failed, Try Again
                </div>
                ";
            }
        }

        // Registration Form Processing
        if (isset($_POST['sign'])) {
            $name = $_POST['fname'];
            $sname = $_POST['sname'];
            $username = $_POST['uname'];
            $email = $_POST['uemail'];
            $pass = sha1($_POST['pass']);
            $cpass = sha1($_POST['cpass']);
            $id = $_POST['id'];
            $tel = $_POST['tel'];
            if ($pass != $cpass) {
                echo "
                <div class='alert alert-danger' id='alert'>
                <a href='#' data-dismiss='alert' class='close'>&times</a>
                <strong>Error!!!</strong>Your Passwords Do Not Match
                </div>
                ";
            } else {
                // Adjusted SQL query to insert data into the 'users' table
                $sql = "INSERT INTO users (fname, sname, username, email, password, c_id, c_tel, type)
                        VALUES ('$name', '$sname', '$username', '$email', '$pass', '$id', '$tel', 'Customer')";
                $query = mysqli_query($conn, $sql);
                if ($query) {
                    echo "
                    <div class='alert alert-success' id='alert'>
                    <a href='#' data-dismiss='alert' class='close'>&times</a>
                    <strong>Success</strong>You are Now Registered. Please Login To Continue
                    </div>
                    ";
                } else {
                    echo "
                    <div class='alert alert-danger' id='alert'>
                    <a href='#' data-dismiss='alert' class='close'>&times</a>
                    <strong>Error!!!</strong>Registration Failed, Try Again
                    </div>
                    ";
                }
            }
        }
        ?>
        <!-- Login Form -->
        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
          <fieldset>
            <legend id="header"><p>Login</p></legend>
            <label for="Username" class="label-control">Username</label>
            <input type="text" name="username" class="form-control input-md" placeholder="Enter the Username here" required/>
            <label for="Password" class="label-control">Password</label>
            <input type="password" name="password" class="form-control input-md" placeholder="Enter the Password here" required />
            <br/>
            <button type="submit" class="btn btn-primary btn-block" name="sub">Login</button>
            <br/>
            <!-- Show Signup Option -->
            <a href="#" class="show-signup" onclick="showSignUpForm()">Not A member? Sign Up</a>
          </fieldset>
        </form>
        
        <!-- Signup Form -->
        <form class="signup-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
          <fieldset>
            <legend id="header"><p>Sign Up</p></legend>
            <label for="Username" class="label-control">First Name</label>
            <input type="text" name="fname" class="form-control input-md" placeholder="Enter First Name" required/>
            <label for="Username" class="label-control">Last Name</label>
            <input type="text" name="lname" class="form-control input-md" placeholder="Enter Last Name" required/>
            <label for="Username" class="label-control">Username</label>
            <input type="text" name="uname" class="form-control input-md" placeholder="Enter Username" required/>
            <label for="Username" class="label-control">Email</label>
            <input type="email" name="uemail" class="form-control input-md" placeholder="Enter Email" required/>
            <label for="Password" class="label-control">Password</label>
            <input type="password" name="pass" class="form-control input-md" placeholder="Enter Password" required />
            <label for="Password" class="label-control">Confirm Password</label>
            <input type="password" name="cpass" class="form-control input-md" placeholder="Confirm Password" required />
            <label for="Username" class="label-control">Id Card Number</label>
            <input type="number" name="id" class="form-control input-md" placeholder="Enter Id Card Number" required/>
            <label for="Username" class="label-control">Telephone Number</label>
            <input type="number" name="tel" class="form-control input-md" placeholder="Enter Telephone Number" required/>
            <br/>
            <button type="submit" class="btn btn-primary btn-block" name="sign">Sign Up</button>
          </fieldset>
        </form>
      </div>
    </div>
  </body>
</html>
