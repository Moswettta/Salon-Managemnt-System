<div class="row sidebar">
<ul class="list-group">
    <li class="list-group-item"><a href="employees.php">Employees</a></li>
  <li class="list-group-item"><a href="services.php">Services</a></li>
  <li class="list-group-item"><a href="clients.php">Clients</a></li>
  <li class="list-group-item"><a href="appointments.php">Appointments</a></li>
  <li class="list-group-item"><a href="view_all.php">View All Appointments</a></li>
  <li class="list-group-item"><a href="emp.php">View All Employees</a></li>
  <li class="list-group-item"><a href="ac.php">View All Clients</a></li>
  <li class="list-group-item"><a href="messages.php">Messages</a></li>
  <li class="list-group-item"><a href="types.php">Service Types</a></li>
  <li class="list-group-item"><a href="logout.php" style="font-size:20px">&nbsp;&nbsp;&nbsp;Sign Out</a></li>
</ul>
</div>
