<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['user'])) {
    header("Location: auth.php");
    exit();
}

// Database connection
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "salon");

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$user = $_SESSION['user'];

// Fetch user ID and name
$user_query = "SELECT c_id, fname FROM users WHERE username='$user'";
$user_result = mysqli_query($conn, $user_query);
if (!$user_result) {
    die("User Query failed: " . mysqli_error($conn));
}
$user_data = mysqli_fetch_assoc($user_result);
$c_id = $user_data['c_id'];
$customer_name = $user_data['fname'];

// Fetch appointment and payment details including assigned employee
$invoice_query = "
SELECT a.id as appointment_id, a.date, a.time, a.service_name, a.price, c.amount, c.payment_status, c.payment_date, e.first_name, e.last_name 
FROM appointments a
JOIN checkout_details c ON a.id = c.appointment_id
LEFT JOIN employees e ON a.employee_id = e.id
WHERE a.c_id='$c_id' AND a.status='Approved' AND c.payment_status='Completed'
";
$invoice_result = mysqli_query($conn, $invoice_query);
if (!$invoice_result) {
    die("Invoice Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
        body {
            font-family: cursive;
            margin: 0;
            padding: 0;
        }
        #header, #headerb {
            font-size: 20px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }
        #header {
            font-size: 30px;
        }
        .navbar {
            background-color: black;
            color: white;
        }
        .container-fluid {
            padding-left: 0;
            padding-right: 0;
        }
        .service-list {
            margin-top: 20px;
        }
        .service-list li {
            list-style-type: none;
            font-size: 18px;
            margin-bottom: 5px;
        }
        .delete-btn {
            margin-left: 10px;
        }
        .alert {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
        }
        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }
        .sidebar-container {
            padding: 20px;
            background-color: #f5f5f5;
            border-right: 1px solid #ddd;
            min-height: 100vh;
        }
        .main-content {
            padding: 20px;
        }
        .types-container {
            margin-top: 20px;
        }
        .print-btn {
            margin-bottom: 20px;
        }
    </style>
    <script>
        function printSelectedInvoices() {
            var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
            if (checkboxes.length === 0) {
                alert("Please select at least one invoice to print.");
                return;
            }

            var printContents = "";
            checkboxes.forEach(function(checkbox) {
                var row = checkbox.closest('tr');
                printContents += row.outerHTML;
            });

            var originalContents = document.body.innerHTML;

            document.body.innerHTML = "<table class='table table-bordered'><thead><tr><th>Appointment ID</th><th>Date</th><th>Time</th><th>Service</th><th>Price</th><th>Amount Paid</th><th>Payment Status</th><th>Payment Date</th><th>Customer Name</th><th>Assigned Employee</th></tr></thead><tbody>" + printContents + "</tbody></table>";

            window.print();

            document.body.innerHTML = originalContents;
        }
    </script>
</head>
<body>
<div class="container-fluid">
    <nav class="navbar">
        <div class="navbar-brand" id="header">
            <a href="dashboard.php" style="color: white; text-decoration: none;">Melly's Salon Management System</a>
        </div>
    </nav>
    <div class="row">
        <div class="col-lg-2 sidebar-container">
            <?php include('C:/xampp/htdocs/salon/customer/sidebar.php'); ?>
        </div>
        <div class="col-lg-10 main-content">
            <div class="container">
                <h1>Invoice Details</h1>
                <h3>Customer: <?php echo htmlspecialchars($customer_name); ?></h3>
                <button class="btn btn-primary print-btn" onclick="printSelectedInvoices()">Print Selected Invoices</button>
                <div id="invoiceDetails">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Select</th>
                                <th>Appointment ID</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Service</th>
                                <th>Price</th>
                                <th>Amount Paid</th>
                                <th>Payment Status</th>
                                <th>Payment Date</th>
                                <th>Customer Name</th>
                                <th>Assigned Employee</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (mysqli_num_rows($invoice_result) > 0) {
                                while ($row = mysqli_fetch_assoc($invoice_result)) {
                                    $employee_name = $row['first_name'] . ' ' . $row['last_name'];
                                    echo "<tr>";
                                    echo "<td><input type='checkbox' value='" . htmlspecialchars($row['appointment_id']) . "'></td>";
                                    echo "<td>" . htmlspecialchars($row['appointment_id']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['time']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['service_name']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['price']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['amount']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['payment_status']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['payment_date']) . "</td>";
                                    echo "<td>" . htmlspecialchars($customer_name) . "</td>";
                                    echo "<td>" . htmlspecialchars($employee_name) . "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='11' class='text-center'>No completed payments found.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                    <?php
                    if (mysqli_num_rows($invoice_result) == 0) {
                        echo "
                        <div class='alert alert-warning text-center'>
                            No completed payments found for your account.
                        </div>
                        ";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

<?php
mysqli_close($conn);
?>
