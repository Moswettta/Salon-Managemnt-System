<?php
include('config.php');
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['appointment_id'])) {
    $appointmentId = $_GET['appointment_id'];
    
    // Check if payment already exists for this appointment
    $checkPaymentSql = "SELECT id FROM checkout_details WHERE appointment_id = ?";
    $checkPaymentStmt = $conn->prepare($checkPaymentSql);
    $checkPaymentStmt->bind_param('i', $appointmentId);
    $checkPaymentStmt->execute();
    $checkPaymentResult = $checkPaymentStmt->get_result();
    
    if ($checkPaymentResult->num_rows > 0) {
        // Payment already exists, do not proceed with payment
        die('Payment has already been made for this appointment.');
    }
    
    // Query to fetch appointment details
    $sql = "SELECT a.id AS appointment_id, a.c_id, a.date, a.time, s.name AS service_name, s.price, a.status, u.fname, u.sname
            FROM appointments a
            LEFT JOIN services s ON a.service = s.service_id
            LEFT JOIN users u ON a.c_id = u.c_id
            WHERE a.id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    
    $stmt->bind_param('i', $appointmentId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $appointment = $result->fetch_assoc();
        $clientId = $appointment['c_id'];
        $clientName = $appointment['fname'] . ' ' . $appointment['sname'];
        $servicePrice = $appointment['price'];
        
        // Check if the appointment status is Approved
        if ($appointment['status'] !== 'Approved') {
            die('Appointment is not approved.');
        }
        
        // Insert into checkout_details table
        $insertSql = "INSERT INTO checkout_details (appointment_id, client_id, amount, payment_status)
                      VALUES (?, ?, ?, 'Completed')";
        
        $insertStmt = $conn->prepare($insertSql);
        if ($insertStmt === false) {
            die('Prepare failed: ' . htmlspecialchars($conn->error));
        }
        
        // Calculate amount (for demonstration, use service price)
        $amount = $servicePrice;
        
        $insertStmt->bind_param('iid', $appointmentId, $clientId, $amount);
        $insertStmt->execute();
        $insertStmt->close();
        
        // Redirect to invoice.php after payment confirmation
        header("Location: invoice.php");
        exit();

    } else {
        die('Appointment not found.');
    }
} else {
    die('Invalid request.');
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo htmlspecialchars(TITLE); ?></title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
        /* Add your custom styles here */
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-6 offset-lg-3">
            <div class="text-center mt-5">
                <h2>Checkout</h2>
                <div class="alert alert-success">
                    Payment successful! Redirecting...
                </div>
                <!-- No need to display details here, as we're redirecting -->
            </div>
        </div>
    </div>
</div>
</body>
</html>
