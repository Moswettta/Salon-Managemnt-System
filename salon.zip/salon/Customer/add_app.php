<?php
// config.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "salon";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

define('TITLE', 'Melly\'s Salon'); // Define your title

session_start();
if (isset($_SESSION['user'])) {
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo TITLE; ?></title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
        #head {
            font-family: cursive;
            font-size: 20px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }
        #header {
            font-family: cursive;
            font-size: 30px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }
        #headerb {
            color: white;
            font-family: cursive;
            font-size: 20px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }
        .navbar {
            background-color: black;
            color: white;
            padding-left: 500px;
        }
        .disabled-option {
            color: grey;
        }
    </style>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const form = document.querySelector('form');
        const dateInput = document.querySelector('input[name="adate"]');
        
        form.addEventListener('submit', function(e) {
            const selectedDate = new Date(dateInput.value);
            const currentDate = new Date();
            
            // Reset time to midnight for comparison
            currentDate.setHours(0, 0, 0, 0);

            if (selectedDate < currentDate) {
                e.preventDefault(); // Prevent form submission
                alert("Error: You cannot book an appointment for a past date.");
            }
        });
    });
    </script>
</head>
<body>
<div class="row">
    <nav class="navbar container-fluid">
        <div class="navbar-brand" id="header"><a href="../Customer" style="color:white;text-decoration:none;">Melly's Salon Management System</a></div>
    </nav>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2" style="margin-left:0px;">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <?php
            $n = $_SESSION['user'];
            $sql = "SELECT c_id FROM users WHERE username='$n'";
            $query = mysqli_query($conn, $sql);
            if ($row = mysqli_fetch_array($query)) {
                $id = $row['c_id'];
            }
            if (isset($_POST['sub'])) {
                $ser = $_POST['service'];
                $ad = $_POST['adate'];
                $at = $_POST['atime'] . " " . $_POST['at'];

                // Check if the selected date is in the past
                if ($ad < date('Y-m-d')) {
                    echo "
                    <div class='alert alert-danger'>
                        <strong>Error:</strong> You cannot book an appointment for a past date.
                    </div>
                    ";
                } else {
                    // Check if the customer already has a pending appointment for the selected service
                    $sql_check = "SELECT * FROM appointments WHERE c_id='$id' AND service='$ser' AND status = 'Pending' AND date >= CURDATE()";
                    $result_check = mysqli_query($conn, $sql_check);
                    if (mysqli_num_rows($result_check) > 0) {
                        echo "
                        <div class='alert alert-danger'>
                            <strong>Error:</strong> You already have a pending appointment for this service. Please wait for admin approval or rejection before booking again.
                        </div>
                        ";
                    } else {
                        // Fetch service details including price
                        $sql_service = "SELECT * FROM services WHERE service_id='$ser'";
                        $result_service = mysqli_query($conn, $sql_service);
                        if ($result_service) {
                            $row_service = mysqli_fetch_assoc($result_service);
                            if ($row_service) {
                                $service_name = $row_service['name'];
                                $service_price = $row_service['price'];

                                // Insert appointment with service details and status pending
                                $sql = "INSERT INTO appointments (date, time, c_id, service, service_name, price, status) VALUES ('$ad', '$at', '$id', '$ser', '$service_name', '$service_price', 'Pending')";
                                $quer = mysqli_query($conn, $sql);
                                if ($quer) {
                                    echo "
                                    <div class='alert alert-success'>
                                        <strong>Success!!!</strong> Appointment request sent. Please wait for admin approval.
                                    </div>
                                    ";
                                } else {
                                    echo "
                                    <div class='alert alert-danger'>
                                        <strong>Error:</strong> Failed to send appointment request: " . mysqli_error($conn) . "
                                    </div>
                                    ";
                                }
                            } else {
                                echo "
                                <div class='alert alert-danger'>
                                    <strong>Error:</strong> Service not found.
                                </div>
                                ";
                            }
                        } else {
                            echo "
                            <div class='alert alert-danger'>
                                <strong>Error:</strong> " . mysqli_error($conn) . "
                            </div>
                            ";
                        }
                    }
                }
            }
            ?>
            <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form" style="margin-top:30px">
                <fieldset><legend id="header" style="color:white">Add New Appointment</legend>
                    <div class="row">
                        <div class="col-lg-3">
                            <label for="service" class="label-control" id="headerb">Service Type</label>
                            <select name="service" class="form-control input-md" required autofocus>
                                <?php
                                // Fetch all services from database
                                $sql_services = "SELECT s.service_id, s.name, s.price, 
                                                 (SELECT COUNT(*) FROM appointments a WHERE a.service = s.service_id AND a.c_id='$id' AND a.status = 'Pending' AND a.date >= CURDATE()) as is_booked 
                                                 FROM services s";
                                $result_services = mysqli_query($conn, $sql_services);
                                if (mysqli_num_rows($result_services) > 0) {
                                    while ($row_services = mysqli_fetch_assoc($result_services)) {
                                        $disabled = ($row_services['is_booked'] > 0) ? "disabled" : "";
                                        $message = ($row_services['is_booked'] > 0) ? " - You have already booked the service" : "";
                                        echo "<option value='" . $row_services['service_id'] . "' class='" . ($disabled ? "disabled-option" : "") . "' $disabled>" . htmlspecialchars($row_services['name']) . " - $" . $row_services['price'] . $message . "</option>";
                                    }
                                } else {
                                    echo "<option>No available services found</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-lg-3">
                            <label for="adate" class="label-control" id="headerb">Appointment Date</label>
                            <input type="date" class="form-control input-md" name="adate" placeholder="Eg. 2024-07-09" required/>
                        </div>
                        <div class="col-lg-3">
                            <label for="atime" class="label-control" id="headerb">Appointment Time</label>
                            <input type="time" class="form-control input-md" name="atime" placeholder="Eg. 14:00" required/>
                        </div>
                        <div class="col-lg-3">
                            <label for="at" class="label-control" id="headerb">Time of Day</label>
                            <select name="at" class="form-control input-md" required>
                                <option value="AM">AM</option>
                                <option value="PM">PM</option>
                            </select>
                        </div>
                    </div><br/>
                    <button class="btn btn-block btn-primary" type="submit" name="sub" id="headerb">Book Appointment</button>
                </fieldset>
            </form>
        </div>
    </div>
</div>
</body>
</html>
<?php 
} else {
    header("Location: ../");
}
mysqli_close($conn);
?>
