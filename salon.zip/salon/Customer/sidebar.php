<div class="row sidebar">
<ul class="list-group">
  <li class="list-group-item"><a href="services.php">Services</a></li>
  <li class="list-group-item"><a href="appointments.php">Appointments</a></li>
  <li class="list-group-item"><a href="view_all.php">View All Appointments</a></li>
  <li class="list-group-item"><a href="invoice.php">Invoices</a></li>
 

  <li class="list-group-item"><a href="logout.php" style="font-size:20px">&nbsp;&nbsp;&nbsp;Sign Out</a></li>
</ul>
</div>
