<?php
include('config.php'); // Ensure your database connection is included
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Available Services</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
        body {
            font-family: cursive;
            margin: 0;
            padding: 0;
        }
        #header, #headerb {
            font-size: 20px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }
        #header {
            font-size: 30px;
        }
        .navbar {
            background-color: black;
            color: white;
        }
        .container-fluid {
            padding-left: 0;
            padding-right: 0;
        }
        .service-list {
            margin-top: 20px;
        }
        .service-list li {
            list-style-type: none;
            font-size: 18px;
            margin-bottom: 5px;
        }
        .delete-btn {
            margin-left: 10px;
        }
        .alert {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
        }
        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }
        .sidebar-container {
            padding: 20px;
            background-color: #f5f5f5;
            border-right: 1px solid #ddd;
            min-height: 100vh;
        }
        .main-content {
            padding: 20px;
        }
        .types-container {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <nav class="navbar">
        <div class="navbar-brand" id="header">
            <a href="dashboard.php" style="color: white; text-decoration: none;">Melly's Salon Management System</a>
        </div>
    </nav>
    <div class="row">
        <div class="col-lg-2 sidebar-container">
            <?php include('C:/xampp/htdocs/salon/Customer/sidebar.php'); ?>
        </div>
        <div class="col-lg-10 main-content">
            <div class="container">
                <h2 class="mb-4">Available Services</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Service Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Duration (minutes)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT * FROM services";
                        $result = mysqli_query($conn, $query);
                        if (!$result) {
                            die("Query failed: " . mysqli_error($conn));
                        }
                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['description']) . "</td>";
                                echo "<td>$" . number_format($row['price'], 2) . "</td>";
                                echo "<td>" . htmlspecialchars($row['duration']) . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='4'>No services found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
