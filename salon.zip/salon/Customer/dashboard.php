<?php
echo"
<script>window.open('index.php','_self')</script>
";
?>
