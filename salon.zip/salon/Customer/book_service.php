<?php
include('config.php');
session_start();
if(isset($_SESSION['user'])){
  if(isset($_POST['service_id'], $_POST['appointment_date'], $_POST['appointment_time'])){
    $service_id = $_POST['service_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    
    // Fetch client ID from session or any other method
    $client_id = 1; // Example client ID, replace with actual method to fetch client ID
    
    // Insert appointment into appointments table
    $sql = "INSERT INTO appointments (c_id, date, time, service) VALUES ('$client_id', '$appointment_date', '$appointment_time', '$service_id')";
    $result = mysqli_query($conn, $sql);
    if($result){
      echo "<script>alert('Appointment booked successfully!');</script>";
      echo "<script>window.location.href = 'appointments.php';</script>";
    } else {
      echo "<script>alert('Failed to book appointment!');</script>";
      echo "<script>window.history.back();</script>";
    }
  } else {
    echo "<script>alert('Missing booking details!');</script>";
    echo "<script>window.history.back();</script>";
  }
} else {
  header("Location: ../");
}
?>
