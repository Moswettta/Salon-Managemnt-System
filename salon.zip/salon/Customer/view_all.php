<?php
include('config.php');
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo htmlspecialchars(TITLE); ?></title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
        #head, #header {
            font-family: cursive;
            font-size: 20px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }

        #header {
            font-size: 30px;
        }

        .navbar {
            background-color: black;
            color: white;
            padding-left: 500px;
        }
    </style>
</head>
<body>
<div class="row">
    <nav class="navbar container-fluid">
        <div class="navbar-brand" id="header">
            <a href="dashboard.php" style="color: white; text-decoration: none;">Melly's Salon Management System</a>
        </div>
    </nav>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <div class="container-fluid text-center mb-3">
                <span id="header">Your Appointments</span>
            </div>
            <table class="table table-bordered table-striped" style="color: #2C2D6E; font-family: cursive; font-weight: bold;">
                <thead>
                <tr>
                    <th>Appointment ID</th>
                    <th>Client Name</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Service</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Assigned Atendant</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $username = $_SESSION['user'];
                
                // Retrieve the user's client ID and name
                $sql = "SELECT c_id, CONCAT(fname, ' ', sname) AS name FROM users WHERE username = ?";
                $stmt = $conn->prepare($sql);
                if ($stmt === false) {
                    die('Prepare failed: ' . htmlspecialchars($conn->error));
                }
                $stmt->bind_param('s', $username);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($row = $result->fetch_assoc()) {
                    $clientId = $row['c_id'];
                    $clientName = $row['name'];

                    // Fetch the user's appointments with service and employee details
                    $appointmentsSql = "
                        SELECT a.id AS appointment_id, a.date, a.time, s.name AS service_name, s.price, a.status, e.first_name, e.last_name 
                        FROM appointments a 
                        LEFT JOIN services s ON a.service = s.service_id 
                        LEFT JOIN employees e ON a.employee_id = e.id 
                        WHERE a.c_id = ?";
                    $appointmentsStmt = $conn->prepare($appointmentsSql);
                    if ($appointmentsStmt === false) {
                        die('Prepare failed: ' . htmlspecialchars($conn->error));
                    }
                    $appointmentsStmt->bind_param('i', $clientId);
                    $appointmentsStmt->execute();
                    $appointmentsResult = $appointmentsStmt->get_result();

                    while ($appointment = $appointmentsResult->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($appointment['appointment_id']); ?></td>
                            <td><?php echo htmlspecialchars($clientName); ?></td>
                            <td><?php echo htmlspecialchars($appointment['date']); ?></td>
                            <td><?php echo htmlspecialchars($appointment['time']); ?></td>
                            <td><?php echo htmlspecialchars($appointment['service_name']); ?></td>
                            <td><?php echo htmlspecialchars($appointment['price']); ?></td>
                            <td><?php
                                if (isset($appointment['status'])) {
                                    echo "<span style='color:" . getStatusColor($appointment['status']) . "'>" . htmlspecialchars($appointment['status']) . "</span>";
                                } else {
                                    echo "<span class='text-muted'>Status Undefined</span>";
                                }
                                ?></td>
                            <td><?php
                                if (!empty($appointment['first_name'])) {
                                    echo htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']);
                                } else {
                                    echo "<span class='text-muted'>Not Assigned</span>";
                                }
                                ?></td>
                            <td>
                                <?php
                                if (isset($appointment['status']) && $appointment['status'] == 'Approved') {
                                    echo "<a href='checkout.php?appointment_id=" . htmlspecialchars($appointment['appointment_id']) . "' class='btn btn-success'>Proceed to Checkout</a>";
                                } else {
                                    echo "<span class='text-muted'>Pending Approval</span>";
                                }
                                ?>
                            </td>
                        </tr>
                        <?php
                    }
                } else {
                    echo "<div class='alert alert-danger'><strong>Error!!!</strong> User not found.</div>";
                }

                function getStatusColor($status) {
                    switch ($status) {
                        case 'Pending':
                            return 'red';
                        case 'Approved':
                            return 'green';
                        case 'Rejected':
                            return 'red';
                        default:
                            return 'black';
                    }
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
