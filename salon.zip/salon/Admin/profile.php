<?php
require('config.php'); // Include your database connection file
session_start();

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['user'];

// Fetch current user data
$stmt = $conn->prepare("SELECT username, password FROM admintbl WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$userData = $result->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newUsername = $_POST['username'];
    $newPassword = $_POST['password'];
    $newCPassword = $_POST['cpassword'];

    // Check if new passwords match
    if ($newPassword != $newCPassword) {
        $error = "Passwords do not match!";
    } else {
        $hashedPassword = sha1($newPassword);

        // Update the user's information
        $stmt = $conn->prepare("UPDATE admintbl SET username = ?, password = ? WHERE username = ?");
        $stmt->bind_param("sss", $newUsername, $hashedPassword, $username);
        if ($stmt->execute()) {
            $_SESSION['user'] = $newUsername; // Update session username
            $success = "Profile updated successfully!";
            $username = $newUsername; // Update local variable for display
        } else {
            $error = "Failed to update profile!";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile | Admin</title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Admin Profile</h1>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" class="form-control" value="<?php echo htmlspecialchars($username); ?>" required>
            </div>
            <div class="form-group">
                <label for="password">New Password</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter new password" required>
            </div>
            <div class="form-group">
                <label for="cpassword">Confirm New Password</label>
                <input type="password" name="cpassword" id="cpassword" class="form-control" placeholder="Confirm new password" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Profile</button>
        </form>
    </div>
</body>
</html>
