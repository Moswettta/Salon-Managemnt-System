<?php
include('config.php');
session_start();
if(isset($_SESSION['user'])){
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo TITLE;?></title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
        #header {

            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 30px;
            font-weight: bold;
            text-shadow: 2px 2px 5px rgba(255, 0, 0, 0.5);
            text-align: center;
            margin-bottom: 20px;
        }
        .navbar {
            background-color: black;
            color: #fff;
            padding: 15px 0;
            text-align: center;
        }
        .card {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: 0.3s;
        }
        .card:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .card-header {
            background-color: #f2f2f2;
            font-weight: bold;
            padding: 10px;
            border-bottom: 1px solid #ccc;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }
        .card-body {
            padding: 10px;
        }
        .row-margin-top {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <nav class="navbar">
                <marquee><div class="navbar-brand" id="header">
                    Melly's Salon Management System
                </div></marquee>
            </nav>
        </div>
    </div>
    <div class="row row-margin-top">
        <div class="col-lg-2">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">Customers</div>
                        <div class="card-body">
                            <?php
                            $sqlCustomers = "SELECT COUNT(*) as total_customers FROM users WHERE type='Customer'";
                            $queryCustomers = mysqli_query($conn, $sqlCustomers);

                            if (!$queryCustomers) {
                                echo "Error fetching customers: " . mysqli_error($conn);
                            } else {
                                $rowCustomers = mysqli_fetch_assoc($queryCustomers);
                                $numCustomers = $rowCustomers['total_customers'];
                                ?>
                                <h3>Total Customers: <?php echo $numCustomers; ?></h3>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">Services</div>
                        <div class="card-body">
                            <?php
                            $sqlServices = "SELECT COUNT(*) as total_services FROM types";
                            $queryServices = mysqli_query($conn, $sqlServices);

                            if (!$queryServices) {
                                echo "Error fetching services: " . mysqli_error($conn);
                            } else {
                                $rowServices = mysqli_fetch_assoc($queryServices);
                                $numServices = $rowServices['total_services'];
                                ?>
                                <h3>Total Services: <?php echo $numServices; ?></h3>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row row-margin-top">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">Appointments</div>
                        <div class="card-body">
                            <?php
                            $sqlAppointments = "SELECT COUNT(*) as total_appointments FROM appointments";
                            $queryAppointments = mysqli_query($conn, $sqlAppointments);

                            if (!$queryAppointments) {
                                echo "Error fetching appointments: " . mysqli_error($conn);
                            } else {
                                $rowAppointments = mysqli_fetch_assoc($queryAppointments);
                                $numAppointments = $rowAppointments['total_appointments'];
                                ?>
                                <h3>Total Appointments: <?php echo $numAppointments; ?></h3>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

<?php } else{
    header("Location: ../Admin");
}?>
