<?php
include('config.php');
session_start();
if(isset($_SESSION['user'])){
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo TITLE;?></title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
        #head {
            font-family: cursive;
            font-size: 20px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }
        #header {
            font-family: cursive;
            font-size: 30px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }
        .navbar {
            background-color: black;
            color: white;
            padding-left: 500px;
        }
    </style>
</head>
<body>
<div class="row">
    <nav class="navbar container-fluid">
        <div class="navbar-brand" id="header">
            <a href="dashboard.php" style="color:white;text-decoration:none;">Melly's Salon Management System</a>
        </div>
    </nav>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2" style="margin-left:0px;">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <div class="container-fluid" style="text-align:center;margin-bottom:10px">
                <a href="add_app.php" class="btn btn-warning">New Appointment</a>
            </div>
            <span id="header">Appointments</span>
            <?php
            if(isset($_GET['approve'])){
                $approve = $_GET['approve'];
                $sql = "UPDATE appointments SET status='Approved' WHERE id='$approve'";
                $upd = mysqli_query($conn, $sql);
                if($upd){
                    echo "
                    <div class='alert alert-success'>
                        <strong>Success</strong> Appointment Approved
                    </div>
                    ";
                } else {
                    echo "
                    <div class='alert alert-danger'>
                        <strong>Error!!!</strong> Appointment Not Approved
                    </div>
                    ";
                }
            }

            if(isset($_GET['reject'])){
                $reject = $_GET['reject'];
                $sql = "UPDATE appointments SET status='Rejected' WHERE id='$reject'";
                $upd = mysqli_query($conn, $sql);
                if($upd){
                    echo "
                    <div class='alert alert-success'>
                        <strong>Success</strong> Appointment Rejected
                    </div>
                    ";
                } else {
                    echo "
                    <div class='alert alert-danger'>
                        <strong>Error!!!</strong> Appointment Not Rejected
                    </div>
                    ";
                }
            }

            if(isset($_POST['assign_employee'])){
                $appointment_id = $_POST['appointment_id'];
                $employee_id = $_POST['employee_id'];
                $sql = "UPDATE appointments SET employee_id='$employee_id' WHERE id='$appointment_id'";
                $upd = mysqli_query($conn, $sql);
                if($upd){
                    echo "
                    <div class='alert alert-success'>
                        <strong>Success</strong> Employee Assigned
                    </div>
                    ";
                } else {
                    echo "
                    <div class='alert alert-danger'>
                        <strong>Error!!!</strong> Employee Not Assigned
                    </div>
                    ";
                }
            }
            ?>
            <table class="table table-bordered table-striped" style="color:#2C2D6E;font-family:cursive;font-weight:bold;">
                <thead>
                <tr>
                    <td>Client Name</td>
                    <td>Date</td>
                    <td>Time</td>
                    <td>Service</td>
                    <td>Status</td>
                    <td>Assigned Employee</td>
                    <td colspan="3" class="text-center">Action</td>
                </tr>
                </thead>
                <tbody>
                <?php
                $query = "SELECT 
                            a.id AS appointment_id,
                            CONCAT(u.fname, ' ', u.sname) AS client_name,
                            a.date,
                            a.time,
                            a.service_name,
                            a.price,
                            a.status,
                            CONCAT(e.first_name, ' ', e.last_name) AS employee_name
                          FROM 
                            appointments a
                          LEFT JOIN 
                            users u ON a.c_id = u.c_id
                          LEFT JOIN 
                            employees e ON a.employee_id = e.id";
                $result = mysqli_query($conn, $query);
                
                if(!$result) {
                    die('Query failed: ' . mysqli_error($conn));
                }
                
                if(mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        ?>
                        <tr>
                            <td><?php echo $row['client_name'];?></td>
                            <td><?php echo $row['date'];?></td>
                            <td><?php echo $row['time'];?></td>
                            <td><?php echo $row['service_name'];?></td>
                            <td><?php
                                $status = $row['status'];
                                if($status == 'Pending') {
                                    echo "<span style='color:red'>Pending</span>";
                                } elseif ($status == 'Approved') {
                                    echo "<span style='color:green'>Approved</span>";
                                } elseif ($status == 'Rejected') {
                                    echo "<span style='color:red'>Rejected</span>";
                                }
                            ?></td>
                            <td><?php echo $row['employee_name'];?></td>
                            <td><a class="btn btn-success btn-block" href="appointments.php?approve=<?php echo $row['appointment_id']; ?>">Approve</a></td>
                            <td><a class="btn btn-primary btn-block" href="appointments.php?reject=<?php echo $row['appointment_id']; ?>">Reject</a></td>
                            <td>
                                <form method="POST" action="appointments.php">
                                    <input type="hidden" name="appointment_id" value="<?php echo $row['appointment_id']; ?>">
                                    <div class="form-group">
                                        <select name="employee_id" class="form-control">
                                            <?php
                                            $emp_query = "SELECT id, CONCAT(first_name, ' ', last_name) AS name FROM employees";
                                            $emp_result = mysqli_query($conn, $emp_query);
                                            while($emp = mysqli_fetch_assoc($emp_result)) {
                                                echo "<option value='{$emp['id']}'>{$emp['name']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-warning btn-block" name="assign_employee">Assign Employee</button>
                                </form>
                            </td>
                        </tr>
                        <?php
                    }
                } else {
                    echo "<tr><td colspan='8'>No appointments found.</td></tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>

<?php } else {
    header("Location: ../Admin");
}?>
