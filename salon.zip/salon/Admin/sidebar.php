<div class="row sidebar">
<ul class="list-group">
    <li class="list-group-item"><a href="dashboard.php">Dashboard</a></li>
    <li class="list-group-item"><a href="employee.php">Employees</a></li>
    <li class="list-group-item"><a href="new_service.php">Services</a></li>
    <li class="list-group-item"><a href="types.php">Service types</a></li>
  <li class="list-group-item"><a href="clients.php">Clients</a></li>
  <li class="list-group-item"><a href="appointments.php">Appointments</a></li>
  <li class="list-group-item"><a href="Profile.php">Profile</a></li>
  <li class="list-group-item"><a href="view_all.php">Reports</a></li>
  
  
  <li class="list-group-item"><a href="logout.php" style="font-size:20px">&nbsp;&nbsp;&nbsp;Sign Out</a></li>
</ul>
</div>
