<?php
include('config.php');
session_start();

$name = '';
$description = '';
$price = '';
$duration = '';
$type_id = '';

if(isset($_SESSION['user'])) {

    // Add Service
    if(isset($_POST['add_service'])) {
        $name = $_POST['name'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $duration = $_POST['duration'];
        $type_id = $_POST['type_id']; // Assuming type_id is coming from a form field

        // Log the data being inserted for debugging purposes
        error_log("Adding service - Name: $name, Description: $description, Price: $price, Duration: $duration, Type ID: $type_id");

        // Insert into services table
        $sql = "INSERT INTO services (name, description, price, duration, type_id) 
                VALUES ('$name', '$description', '$price', '$duration', '$type_id')";

        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>New service added successfully</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div>";
        }
    }

    // Delete Service
    if(isset($_GET['delete_service'])) {
        $delete_id = $_GET['delete_service'];
        $sql = "DELETE FROM services WHERE service_id='$delete_id'";
        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>Service deleted successfully</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div>";
        }
    }

    // Edit Service
    if(isset($_POST['edit_service'])) {
        $edit_id = $_POST['edit_id'];
        $name = $_POST['name'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $duration = $_POST['duration'];
        $type_id = $_POST['type_id'];

        // Log the data being updated for debugging purposes
        error_log("Editing service - ID: $edit_id, Name: $name, Description: $description, Price: $price, Duration: $duration, Type ID: $type_id");

        $sql = "UPDATE services SET name='$name', description='$description', price='$price', duration='$duration', type_id='$type_id' WHERE service_id='$edit_id'";
        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>Service updated successfully</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div>";
        }
    }

    // Add Type
    if(isset($_POST['add_type'])) {
        $type_name = $_POST['type_name'];
        $type_description = $_POST['type_description'];

        // Log the data being inserted for debugging purposes
        error_log("Adding type - Name: $type_name, Description: $type_description");

        // Insert into types table
        $sql = "INSERT INTO types (name, description) 
                VALUES ('$type_name', '$type_description')";

        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>New type added successfully</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div>";
        }
    }

    // Delete Type
    if(isset($_GET['delete_type'])) {
        $delete_type_id = $_GET['delete_type'];
        $sql = "DELETE FROM types WHERE type_id='$delete_type_id'";
        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>Type deleted successfully</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div>";
        }
    }

    // Edit Type
    if(isset($_POST['edit_type'])) {
        $edit_type_id = $_POST['edit_type_id'];
        $type_name = $_POST['edit_type_name'];
        $type_description = $_POST['edit_type_description'];

        // Log the data being updated for debugging purposes
        error_log("Editing type - ID: $edit_type_id, Name: $type_name, Description: $type_description");

        $sql = "UPDATE types SET name='$type_name', description='$type_description' WHERE type_id='$edit_type_id'";
        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>Type updated successfully</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div>";
        }
    }

    // Fetch Types
    $types = []; // Initialize types array
    $types_sql = "SELECT * FROM types";
    $types_result = $conn->query($types_sql);
    if (!$types_result) {
        echo "<div class='alert alert-danger'>Error fetching types: " . $conn->error . "</div>";
    } else {
        while($row = $types_result->fetch_assoc()) {
            $types[] = $row;
        }
    }

    // Fetch Services
    $services = []; // Initialize services array
    $services_sql = "SELECT services.*, types.name as type_name 
                    FROM services 
                    JOIN types ON services.type_id = types.type_id";
    $services_result = $conn->query($services_sql);
    if (!$services_result) {
        echo "<div class='alert alert-danger'>Error fetching services: " . $conn->error . "</div>";
    } else {
        while($row = $services_result->fetch_assoc()) {
            $services[] = $row;
        }
    }

?>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo htmlspecialchars(TITLE); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
        body {
            font-family: cursive;
            margin: 0;
            padding: 0;
        }
        #header, #headerb {
            font-size: 20px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }
        #header {
            font-size: 30px;
        }
        .navbar {
            background-color: black;
            color: white;
        }
        .container-fluid {
            padding-left: 0;
            padding-right: 0;
        }
        .service-list {
            margin-top: 20px;
        }
        .service-list li {
            list-style-type: none;
            font-size: 18px;
            margin-bottom: 5px;
        }
        .delete-btn {
            margin-left: 10px;
        }
        .alert {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
        }
        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }
        .sidebar-container {
            padding: 20px;
            background-color: #f5f5f5;
            border-right: 1px solid #ddd;
            min-height: 100vh;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <nav class="navbar">
        <div class="navbar-brand" id="header">
            <a href="dashboard.php" style="color: white; text-decoration: none;">Melly's Salon Management System</a>
        </div>
    </nav>
    <div class="row">
        <div class="col-lg-2 sidebar-container">
            <?php include('C:/xampp/htdocs/salon/Admin/sidebar.php'); ?>
        </div>

        <div class="col-lg-10">
            <!-- Add Service Form -->
            <form method="POST" action="">
                <h2>Add Service</h2>
                <div class="form-group">
                    <label for="name">Service Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control" id="description" name="description" required><?php echo htmlspecialchars($description); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="price">Price</label>
                    <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?php echo htmlspecialchars($price); ?>" required>
                </div>
                <div class="form-group">
                    <label for="duration">Duration (minutes)</label>
                    <input type="number" class="form-control" id="duration" name="duration" value="<?php echo htmlspecialchars($duration); ?>" required>
                </div>
                <div class="form-group">
                    <label for="type_id">Type</label>
                    <select class="form-control" id="type_id" name="type_id" required>
                        <?php foreach($types as $type) { ?>
                            <option value="<?php echo $type['type_id']; ?>"><?php echo htmlspecialchars($type['name']); ?></option>
                        <?php } ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" name="add_service">Add Service</button>
            </form>

            <hr>

            <!-- Services List -->
            <h2>Services List</h2>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Duration</th>
                    <th>Type</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($services as $service) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($service['service_id']); ?></td>
                        <td><?php echo htmlspecialchars($service['name']); ?></td>
                        <td><?php echo htmlspecialchars($service['description']); ?></td>
                        <td><?php echo htmlspecialchars($service['price']); ?></td>
                        <td><?php echo htmlspecialchars($service['duration']); ?></td>
                        <td><?php echo htmlspecialchars($service['type_name']); ?></td>
                        <td>
                            <a href="?delete_service=<?php echo $service['service_id']; ?>" class="btn btn-danger btn-sm delete-btn">Delete</a>
                            <a href="edit_service.php?service_id=<?php echo $service['service_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
<?php
}
?>
