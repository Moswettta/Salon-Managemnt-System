<?php
include('config.php');
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: ../");
    exit();
}

// Default to daily report if no selection is made
$reportType = isset($_GET['report']) ? $_GET['report'] : 'daily';

// Fetch invoice information based on selected report type
switch ($reportType) {
    case 'daily':
        $sql = "SELECT u.fname AS customer_name, DATE(cd.payment_date) AS invoice_date, s.name AS service_name, SUM(cd.amount) AS total_amount
                FROM checkout_details cd
                INNER JOIN appointments a ON cd.appointment_id = a.id
                INNER JOIN users u ON a.c_id = u.c_id
                INNER JOIN services s ON a.service = s.service_id
                WHERE DATE(cd.payment_date) = CURDATE()
                GROUP BY u.fname, DATE(cd.payment_date), s.name";
        break;
    
    case 'monthly':
        $sql = "SELECT u.fname AS customer_name, YEAR(cd.payment_date) AS invoice_year, MONTH(cd.payment_date) AS invoice_month, s.name AS service_name, SUM(cd.amount) AS total_amount
                FROM checkout_details cd
                INNER JOIN appointments a ON cd.appointment_id = a.id
                INNER JOIN users u ON a.c_id = u.c_id
                INNER JOIN services s ON a.service = s.service_id
                WHERE YEAR(cd.payment_date) = YEAR(CURDATE()) AND MONTH(cd.payment_date) = MONTH(CURDATE())
                GROUP BY u.fname, YEAR(cd.payment_date), MONTH(cd.payment_date), s.name";
        break;
    
    case 'yearly':
        $sql = "SELECT u.fname AS customer_name, YEAR(cd.payment_date) AS invoice_year, s.name AS service_name, SUM(cd.amount) AS total_amount
                FROM checkout_details cd
                INNER JOIN appointments a ON cd.appointment_id = a.id
                INNER JOIN users u ON a.c_id = u.c_id
                INNER JOIN services s ON a.service = s.service_id
                WHERE YEAR(cd.payment_date) = YEAR(CURDATE())
                GROUP BY u.fname, YEAR(cd.payment_date), s.name";
        break;

    default:
        // Handle invalid report type
        die('Invalid report type');
}

$result = mysqli_query($conn, $sql);

if (!$result) {
    die('Query failed: ' . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo TITLE;?></title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
        #header {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 28px;
            font-weight: bold;
            text-shadow: 1px 1px #888;
        }
        .navbar {
            background-color: #343a40;
            color: white;
        }
        .navbar-brand a {
            color: white;
            text-decoration: none;
        }
        .table {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .table thead {
            background-color: #343a40;
            color: white;
        }
        .table tbody tr:nth-child(odd) {
            background-color: #f2f2f2;
        }
        .table tbody tr:nth-child(even) {
            background-color: #ffffff;
        }
        .table td, .table th {
            text-align: center;
            vertical-align: middle;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <nav class="navbar container-fluid">
            <div class="navbar-brand" id="header">
                <a href="#" style="color:white;text-decoration:none;">Melly's Salon Management System</a>
            </div>
        </nav>
    </div>
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <div class="container-fluid">
                <h2 class="text-center mb-4" id="header">Invoice Information</h2>

                <!-- Form to select report type -->
                <form action="" method="get" class="mb-4">
                    <div class="form-group">
                        <label for="reportType">Select Report Type:</label>
                        <select class="form-control" id="reportType" name="report" onchange="this.form.submit()">
                            <option value="daily" <?php echo ($reportType == 'daily') ? 'selected' : ''; ?>>Daily</option>
                            <option value="monthly" <?php echo ($reportType == 'monthly') ? 'selected' : ''; ?>>Monthly</option>
                            <option value="yearly" <?php echo ($reportType == 'yearly') ? 'selected' : ''; ?>>Yearly</option>
                        </select>
                    </div>
                </form>

                <!-- Display invoice information -->
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Customer Name</th>
                            <?php if ($reportType == 'daily'): ?>
                                <th>Date</th>
                            <?php elseif ($reportType == 'monthly'): ?>
                                <th>Month</th>
                                <th>Year</th>
                            <?php elseif ($reportType == 'yearly'): ?>
                                <th>Year</th>
                            <?php endif; ?>
                            <th>Service</th>
                            <th>Total Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['customer_name']) . "</td>";
                        if ($reportType == 'daily') {
                            echo "<td>" . htmlspecialchars($row['invoice_date']) . "</td>";
                        } elseif ($reportType == 'monthly') {
                            echo "<td>" . htmlspecialchars(date('F', mktime(0, 0, 0, $row['invoice_month'], 1))) . "</td>";
                            echo "<td>" . htmlspecialchars($row['invoice_year']) . "</td>";
                        } elseif ($reportType == 'yearly') {
                            echo "<td>" . htmlspecialchars($row['invoice_year']) . "</td>";
                        }
                        echo "<td>" . htmlspecialchars($row['service_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['total_amount']) . "</td>";
                        echo "</tr>";
                    }
                    mysqli_free_result($result);
                    ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
<script src="../Assets/js/bootstrap.min.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>
