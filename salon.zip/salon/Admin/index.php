<?php
require('config.php');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>SMS | Login</title>
  <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../Assets/css/custom.css">
  <link rel="stylesheet" href="../Assets/css/all.min.css">
  <script src="../Assets/js/jquery.min.js"></script>
  <script src="../Assets/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      margin: 0;
      background-color: #e9ecef;
    }
    #header {
      background-color: #343a40;
      color: white;
      padding: 15px;
      text-align: center;
      font-family: 'Arial', sans-serif;
      font-size: 24px;
      font-weight: bold;
    }
    #header a {
      color: white;
      text-decoration: none;
      font-size: 18px;
      position: absolute;
      left: 15px;
      top: 15px;
    }
    .container {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }
    .login-form {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      max-width: 400px;
      width: 100%;
    }
    .login-form h2 {
      margin-bottom: 20px;
      font-family: 'Arial', sans-serif;
      font-size: 24px;
      font-weight: bold;
      text-align: center;
    }
    .label-control {
      font-family: 'Arial', sans-serif;
      font-size: 16px;
      font-weight: bold;
    }
    .form-control {
      border-radius: 4px;
      box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
    }
    .btn-primary {
      background-color: #007bff;
      border-color: #007bff;
    }
    .btn-primary:hover {
      background-color: #0056b3;
      border-color: #004085;
    }
    .alert {
      margin-bottom: 20px;
      border-radius: 4px;
    }
    #footer {
      font-family: 'Arial', sans-serif;
      font-size: 16px;
      font-weight: bold;
      text-align: center;
      padding: 10px;
      background-color: #343a40;
      color: white;
      position: absolute;
      bottom: 0;
      width: 100%;
    }
    .modal-header {
      border-bottom: none;
    }
    .modal-body {
      padding: 20px;
    }
    .modal-footer {
      border-top: none;
    }
    .close {
      color: #343a40;
      opacity: 1;
    }
  </style>
</head>
<body>
  <div id="header">
    <a href="/salon/index.php">Home</a>
    Melly's Salon Management System
  </div>
  <div class="container">
    <div class="login-form">
      <?php
      if (isset($_POST['sub'])) {
        $name = $_POST['username'];
        $pass = sha1($_POST['password']);

        // Prepare SQL statement to avoid SQL injection
        $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
        $stmt->bind_param("ss", $name, $pass);
        $stmt->execute();
        $result = $stmt->get_result();
        $count = $result->num_rows;

        if ($count == 1) {
          session_start();
          $_SESSION['user'] = $name;
          header("Location: dashboard.php");
        } else {
          echo "
          <div class='alert alert-danger' role='alert'>
            <strong>Error!</strong> Login failed, try again.
          </div>
          ";
        }

        $stmt->close(); // Close the statement
      }

      if (isset($_POST['sign'])) {
        $username = $_POST['uname'];
        $email = $_POST['uemail'];

        // Prepare SQL statement to avoid SQL injection
        $stmt = $conn->prepare("SELECT password FROM admin WHERE username = ? AND email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $count = $result->num_rows;

        if ($count == 1) {
          $row = $result->fetch_assoc();
          $retrievedPassword = $row['password'];
          echo "
          <div class='alert alert-success' role='alert'>
            <strong>Success!</strong> Your password is: $retrievedPassword
          </div>
          ";
        } else {
          echo "
          <div class='alert alert-danger' role='alert'>
            <strong>Error!</strong> Username or email is incorrect.
          </div>
          ";
        }

        $stmt->close(); // Close the statement
      }

      if (isset($_POST['register'])) {
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = sha1($_POST['password']);
        $cpassword = sha1($_POST['cpassword']);

        if ($password != $cpassword) {
          echo "
          <div class='alert alert-danger' role='alert'>
            <strong>Error!</strong> Passwords do not match.
          </div>
          ";
        } else {
          // Prepare SQL statement to avoid SQL injection
          $stmt = $conn->prepare("INSERT INTO admin (fname, lname, username, email, password) VALUES (?, ?, ?, ?, ?)");
          $stmt->bind_param("sssss", $fname, $lname, $username, $email, $password);

          if ($stmt->execute()) {
            echo "
            <div class='alert alert-success' role='alert'>
              <strong>Success!</strong> You are now registered. Please login to continue.
            </div>
            ";
          } else {
            echo "
            <div class='alert alert-danger' role='alert'>
              <strong>Error!</strong> Registration failed, try again.
            </div>
            ";
          }

          $stmt->close(); // Close the statement
        }
      }
      ?>
      <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <h2>Login</h2>
        <fieldset>
          <label for="Username" class="label-control">Username</label>
          <input type="text" name="username" class="form-control" placeholder="Enter your username" required minlength="5"/>
          <label for="Password" class="label-control">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Enter your password" required minlength="8"/>
          </br>
          <button type="submit" class="btn btn-primary btn-block" name="sub">Login</button>
        </fieldset>
      </form>
    </div>
  </div>
  <!-- Retrieve Password Modal -->
  <div class="modal fade" id="smodal" tabindex="-1" aria-labelledby="smodalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="smodalLabel">Retrieve Password</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <div class="mb-3">
              <label for="Username" class="form-label">Username</label>
              <input type="text" class="form-control" name="uname" placeholder="Enter your username" required/>
            </div>
            <div class="mb-3">
              <label for="Email" class="form-label">Email Address</label>
              <input type="email" class="form-control" name="uemail" placeholder="Enter your email" required/>
            </div>
            <button type="submit" class="btn btn-primary" name="sign">Retrieve</button>
          </form>
        </div>
        <div class="modal-footer">
          <span>&copy; Melly's Salon Management System</span>
        </div>
      </div>
    </div>
  </div>
  <!-- JavaScript -->
  <script>
    $(document).ready(function(){
      // Handle showing/hiding modals
      $('#smodal').on('show.bs.modal', function (e) {
        $(this).modal('show');
      });
    });
  </script>
</body>
</html>
