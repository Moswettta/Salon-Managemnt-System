<?php
include('config.php');
session_start();
if(isset($_SESSION['user'])){
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo TITLE;?></title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
    #head {
        font-family: cursive;
        font-size: 20px;
        font-weight: bold;
        text-shadow: 2px 2px red;
    }
    #header {
        font-family: cursive;
        font-size: 30px;
        font-weight: bold;
        text-shadow: 2px 2px red;
    }
    .navbar {
        background-color: black;
        color: white;
        padding-left: 500px;
    }
    </style>
</head>
<body>
<div class="row">
    <nav class="navbar container-fluid">
        <div class="navbar-brand" id="header">
            <a href="dashboard.php" style="color:white;text-decoration:none;">Melly's Salon management System</a>
        </div>
    </nav>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2" style="margin-left:0px;">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <span id="header">Clients Details</span>
            <?php
            $c = "SELECT * FROM users WHERE type='Customer'";
            $qr = mysqli_query($conn, $c);
            if (mysqli_num_rows($qr) > 0) {
            ?>
            <table class="table table-bordered table-striped" style="color:#2C2D6E;font-family:cursive;font-weight:bold;">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Second Name</th>
                        <th>Id Number</th>
                        <th>Telephone Number</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($ro = mysqli_fetch_array($qr)) {
                        $fn = $ro['fname'];
                        $sn = $ro['sname'];
                        $customerId = $ro['c_id'];
                        $customerTel = $ro['c_tel'];
                        $customerEmail = $ro['email'];
                    ?>
                    <tr>
                        <td><?php echo $fn;?></td>
                        <td><?php echo $sn;?></td>
                        <td><?php echo $customerId;?></td>
                        <td><?php echo $customerTel;?></td>
                        <td><?php echo $customerEmail;?></td>
                        <td>
                         <td>
    <a href="vc.php?view=<?php echo $customerId;?>" class="btn btn-sm btn-primary">View Details</a>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" style="display: inline;">
        <input type="hidden" name="customer_id" value="<?php echo $customerId; ?>">
        <button type="submit" class="btn btn-sm btn-danger" name="delete_customer">Delete</button>
    </form>
</td>

                    
                    <?php } ?>
                </tbody>
            </table>
            <?php } else {
                echo "<p>No appointments found for clients.</p>";
            } ?>
        </div>
    </div>
</div>
</body>
</html>
<?php
if (isset($_POST['delete_customer'])) {
    $customerId = $_POST['customer_id'];
    $deleteSql = "DELETE FROM users WHERE c_id = ?";
    $stmt = $conn->prepare($deleteSql);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param('i', $customerId);
    if ($stmt->execute()) {
        echo "<script>alert('Customer deleted successfully.');</script>";
        // Redirect or refresh page as needed
    } else {
        echo "<script>alert('Failed to delete customer.');</script>";
    }
}
} else {
  header("Location: ../Admin");
}
?>
