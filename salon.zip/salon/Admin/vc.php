<?php
include('config.php');
session_start();
if(isset($_SESSION['user']) && isset($_GET['view'])) {
    $clientId = $_GET['view'];
    $query = "SELECT * FROM users WHERE c_id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param('i', $clientId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $clientDetails = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo TITLE; ?></title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
    #head {
        font-family: cursive;
        font-size: 20px;
        font-weight: bold;
        text-shadow: 2px 2px red;
    }
    #header {
        font-family: cursive;
        font-size: 30px;
        font-weight: bold;
        text-shadow: 2px 2px red;
    }
    .navbar {
        background-color: black;
        color: white;
        padding-left: 500px;
    }
    </style>
</head>
<body>
<div class="row">
    <nav class="navbar container-fluid">
        <div class="navbar-brand" id="header">
            <a href="dashboard.php" style="color:white;text-decoration:none;">Melly's Salon Management System</a>
        </div>
    </nav>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2" style="margin-left:0px;">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <h2 id="header">Client Details</h2>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Name: <?php echo $clientDetails['fname'] . ' ' . $clientDetails['sname']; ?></h5>
                    <p class="card-text">ID Number: <?php echo $clientDetails['c_id']; ?></p>
                    <p class="card-text">Telephone Number: <?php echo $clientDetails['c_tel']; ?></p>
                    <p class="card-text">Email: <?php echo $clientDetails['email']; ?></p>
                    <!-- Add more details as needed -->
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php
    } else {
        echo "<p>Client details not found.</p>";
    }
} else {
    header("Location: ../Admin");
}
?>
