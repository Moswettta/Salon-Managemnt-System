<?php
include('config.php');
session_start();
if(isset($_SESSION['user'])){
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo TITLE;?></title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
    #head {
        font-family: cursive;
        font-size: 20px;
        font-weight: bold;
        text-shadow: 2px 2px red;
    }
    #header {
        font-family: cursive;
        font-size: 30px;
        font-weight: bold;
        text-shadow: 2px 2px red;
    }
    .navbar {
        background-color: black;
        color: white;
        padding-left: 500px;
    }
    </style>
</head>
<body>
<div class="row">
    <nav class="navbar container-fluid">
        <div class="navbar-brand" id="header">
            <a href="dashboard.php" style="color:white;text-decoration:none;">Melly's Salon Management System</a>
        </div>
    </nav>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2" style="margin-left:0px;">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <span id="header">Employee Details</span>
            <?php
            $e = "SELECT * FROM employees";
            $qr = mysqli_query($conn, $e);
            if (mysqli_num_rows($qr) > 0) {
            ?>
            <table class="table table-bordered table-striped" style="color:#2C2D6E;font-family:cursive;font-weight:bold;">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($row = mysqli_fetch_array($qr)) {
                        $firstName = $row['first_name'];
                        $lastName = $row['last_name'];
                        $email = $row['email'];
                        $phone = $row['phone'];
                        $employeeId = $row['id'];
                    ?>
                    <tr>
                        <td><?php echo $firstName;?></td>
                        <td><?php echo $lastName;?></td>
                        <td><?php echo $email;?></td>
                        <td><?php echo $phone;?></td>
                        <td>
                            <a href="ve.php?view=<?php echo $employeeId;?>" class="btn btn-sm btn-primary">View Details</a>
                            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" style="display: inline;">
                                <input type="hidden" name="employee_id" value="<?php echo $employeeId; ?>">
                                <button type="submit" class="btn btn-sm btn-danger" name="delete_employee">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
            <?php } else {
                echo "<p>No employees found.</p>";
            } ?>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <h3>Add Employee</h3>
                <input type="text" name="first_name" placeholder="First Name" required>
                <input type="text" name="last_name" placeholder="Last Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="text" name="phone" placeholder="Phone" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" class="btn btn-sm btn-success" name="add_employee">Add Employee</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
<?php
if (isset($_POST['delete_employee'])) {
    $employeeId = $_POST['employee_id'];
    $deleteSql = "DELETE FROM employees WHERE id = ?";
    $stmt = $conn->prepare($deleteSql);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param('i', $employeeId);
    if ($stmt->execute()) {
        echo "<script>alert('Employee deleted successfully.');</script>";
        echo "<script>window.location.href = window.location.href;</script>";
    } else {
        echo "<script>alert('Failed to delete employee.');</script>";
    }
}

if (isset($_POST['add_employee'])) {
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $insertSql = "INSERT INTO employees (first_name, last_name, email, phone, password) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertSql);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param('sssss', $firstName, $lastName, $email, $phone, $password);
    if ($stmt->execute()) {
        echo "<script>alert('Employee added successfully.');</script>";
        echo "<script>window.location.href = window.location.href;</script>";
    } else {
        echo "<script>alert('Failed to add employee.');</script>";
    }
}
} else {
  header("Location: ../Admin");
}
?>
