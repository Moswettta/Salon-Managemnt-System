<?php
include('config.php');
session_start();
if(isset($_SESSION['user'])){
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title><?php echo TITLE;?></title>
  <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../Assets/css/custom.css">
  <style>
    #head {
      font-family: cursive;
      font-size: 20px;
      font-weight: bold;
      text-shadow: 2px 2px red;
    }
    #header {
      font-family: cursive;
      font-size: 30px;
      font-weight: bold;
      text-shadow: 2px 2px red;
    }
    #headerb {
      color: white;
      font-family: cursive;
      font-size: 20px;
      font-weight: bold;
      text-shadow: 2px 2px red;
    }
    .navbar {
      background-color: black;
      color: white;
      padding-left: 500px;
    }
  </style>
</head>
<body>
<div class="row">
  <nav class="navbar container-fluid">
    <div class="navbar-brand" id="header"><a href="../Customer" style="color:white;text-decoration:none;">Melly's Salon Management System</a></div>
  </nav>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-lg-2 col-md-2 col-sm-2" style="margin-left:0px;">
      <?php include('sidebar.php'); ?>
    </div>
    <div class="col-lg-10 col-md-10 col-sm-10">
      <?php
      $n=$_SESSION['user'];
      $sql="select c_id from users where username='$n'";
      $query=mysqli_query($conn,$sql);
      if($row=mysqli_fetch_array($query)){
        $id=$row['c_id'];
      }
      if(isset($_POST['sub'])){
        $ser=$_POST['service'];
        $ad=$_POST['adate'];
        $at=$_POST['atime']." ".$_POST['at'];

        // Validate date against existing appointments
        $existing_appointments = array();
        $sql_existing = "SELECT date FROM appointments WHERE c_id='$id'";
        $result_existing = mysqli_query($conn, $sql_existing);
        if($result_existing && mysqli_num_rows($result_existing) > 0) {
          while($row_existing = mysqli_fetch_assoc($result_existing)) {
            $existing_appointments[] = $row_existing['date'];
          }
        }

        // Check if selected date is valid
        $selected_date = date('Y-m-d', strtotime($ad));
        $allowed_dates = array();
        if(!in_array($selected_date, $existing_appointments)) {
          $allowed_dates[] = date('Y-m-d', strtotime($ad . ' -1 day'));
          $allowed_dates[] = $selected_date;
          $allowed_dates[] = date('Y-m-d', strtotime($ad . ' +1 day'));
        }

        if(in_array($selected_date, $existing_appointments)) {
          echo "
          <div class='alert alert-danger'>
            <strong>Error:</strong> You already have an appointment booked on this day.
          </div>
          ";
        } elseif(!in_array(date('Y-m-d'), $allowed_dates)) {
          echo "
          <div class='alert alert-danger'>
            <strong>Error:</strong> You can only book appointments for today or the next two days.
          </div>
          ";
        } else {
          // Fetch service details including price
          $sql_service = "SELECT * FROM services WHERE service_id='$ser'";
          $result_service = mysqli_query($conn, $sql_service);
          if($result_service) {
            $row_service = mysqli_fetch_assoc($result_service);
            if($row_service) {
              $service_name = $row_service['name'];
              $service_price = $row_service['price'];

              // Insert appointment with service details
              $sql = "INSERT INTO appointments (date, time, c_id, service, service_name, price) VALUES ('$ad', '$at', '$id', '$ser', '$service_name', '$service_price')";
              $quer=mysqli_query($conn,$sql);
              if($quer){
                echo "
                <div class='alert alert-success'>
                  <strong>Success!!!</strong> Appointment booked.
                </div>
                ";
              } else {
                echo "
                <div class='alert alert-danger'>
                  <strong>Error:</strong> Appointment booking failed: " . mysqli_error($conn) . "
                </div>
                ";
              }
            } else {
              echo "
              <div class='alert alert-danger'>
                <strong>Error:</strong> Service not found
              </div>
              ";
            }
          } else {
            echo "
            <div class='alert alert-danger'>
              <strong>Error:</strong> " . mysqli_error($conn) . "
            </div>
            ";
          }
        }
      }
      ?>
      <form method="POST" action="<?php $_SERVER['PHP_SELF']?>" class="form" style="margin-top:30px">
        <fieldset><legend id="header" style="color:white">Add New Appointment</legend>
          <div class="row">
            <div class="col-lg-3">
              <label for="service" class="label-control" id="headerb">Service Type</label>
              <select name="service" class="form-control input-md" required autofocus>
                <?php
                // Fetch services from database
                $sql_services = "SELECT * FROM services";
                $result_services = mysqli_query($conn, $sql_services);
                if(mysqli_num_rows($result_services) > 0) {
                  while($row_services = mysqli_fetch_assoc($result_services)) {
                    echo "<option value='" . $row_services['service_id'] . "'>" . htmlspecialchars($row_services['name']) . " - $" . $row_services['price'] . "</option>";
                  }
                } else {
                  echo "<option>No services found</option>";
                }
                ?>
              </select>
            </div>
            <div class="col-lg-3">
              <label for="adate" class="label-control" id="headerb">Appointment Date</label>
              <input type="date" class="form-control input-md" name="adate" placeholder="Eg. 2024-07-09" required/>
            </div>
            <div class="col-lg-3">
              <label for="atime" class="label-control" id="headerb">Appointment Time</label>
              <input type="time" class="form-control input-md" name="atime" placeholder="Eg. 14:00" required/>
            </div>
            <div class="col-lg-3">
              <label for="at" class="label-control" id="headerb">Time of Day</label>
              <select name="at" class="form-control input-md" required>
                <option value="AM">AM</option>
                <option value="PM">PM</option>
              </select>
            </div>
          </div><br/>
          <button class="btn btn-block btn-primary" type="submit" name="sub" id="headerb">Book Appointment</button>
          <input type="hidden"/>
        </fieldset>
      </form>
    </div>
  </div>
</div>
</body>
</html>
<?php } else{
  header("Location: ../");
}?>
