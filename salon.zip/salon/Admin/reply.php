<?php
include('config.php');
session_start();
if (isset($_SESSION['user'])) {
  $id = $_GET['id'];

  // Handle form submission for adding a new type
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['type'])) {
    $type = $_POST['type'];
    $sqlAddType = "INSERT INTO types (type) VALUES ('$type')";
    if (mysqli_query($conn, $sqlAddType)) {
      $message = "Type added successfully.";
    } else {
      $message = "Error adding type: " . mysqli_error($conn);
    }
  }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title><?php echo TITLE; ?></title>
  <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../Assets/css/custom.css">
  <style>
    #head {
      font-family: cursive;
      font-size: 20px;
      font-weight: bold;
      text-shadow: 2px 2px red;
    }
    #header {
      font-family: cursive;
      font-size: 30px;
      font-weight: bold;
      text-shadow: 2px 2px red;
      text-align: center;
    }
    .navbar {
      background-color: black;
      color: white;
      padding: 15px 0;
      text-align: center;
    }
    .message-box {
      margin-top: 20px;
    }
    .message-box .row {
      margin-bottom: 10px;
    }
    .message-box input[type="text"] {
      margin-bottom: 10px;
    }
    .message-box textarea {
      margin-bottom: 20px;
    }
    .service-section {
      margin-top: 50px;
    }
    .service-section .card {
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <nav class="navbar container-fluid">
    <div class="navbar-brand" id="header">
      <a href="dashboard.php" style="color:white;text-decoration:none;">Melly's Salon Management System</a>
    </div>
  </nav>

  <div class="container-fluid">
    <?php
    if (isset($_POST['sub'])) {
      // count the messages
      $sc = "SELECT * FROM messages";
      $query = mysqli_query($conn, $sc);
      $count = mysqli_num_rows($query);
      $message = $_POST['message'];
      $sql1 = "UPDATE messages SET reply='$message' WHERE from_c='$id' AND id='$count'";
      $sql2 = "UPDATE messages SET status='1' WHERE from_c='$id' AND id='$count'";
      $qry1 = mysqli_query($conn, $sql1);
      $qry = mysqli_query($conn, $sql2);
    }
    ?>
    <div class="row">
      <div class="col-lg-2 col-md-2 col-sm-2">
        <?php include('sidebar.php'); ?>
      </div>
      <div class="col-lg-10 col-md-10 col-sm-10">
        <h2 class="text-center" id="header">Messages Center</h2>
        <p class="text-center">Message Sent By Client ID: <?php echo $id; ?></p>
        <div class="row">
          <div class="col-lg-6 text-danger text-center">
            Received
          </div>
          <div class="col-lg-6 text-success text-center">
            Reply
          </div>
        </div>
        <div class="message-box">
          <?php
          $sql = "SELECT * FROM messages WHERE from_c='$id' ORDER BY id DESC LIMIT 3";
          $query = mysqli_query($conn, $sql);
          while ($row = mysqli_fetch_array($query)) {
          ?>
          <div class="row">
            <div class="col-lg-6">
              <input type="hidden" name="id" value="<?php echo $id; ?>" class="form-control" disabled />
              <input type="text" value="<?php echo $row['body']; ?>" class="form-control" disabled />
            </div>
            <div class="col-lg-6">
              <input type="text" value="<?php echo $row['reply']; ?>" class="form-control" disabled />
            </div>
          </div>
          <?php } ?>
        </div>
        <form method="POST" action="<?php $_SERVER['PHP_SELF']; ?>">
          <div class="col-lg-6">
            <textarea name="message" class="form-control" rows="5" placeholder="Type your Message Here"></textarea>
            <button type="submit" class="btn btn-success" name="sub">Send</button>
          </div>
        </form>

        <!-- Service Section -->
        <div class="service-section">
          <!-- Add Type Section -->
          <div class="card">
            <div class="card-header">Add Type</div>
            <div class="card-body">
              <?php if (isset($message)) echo "<p>$message</p>"; ?>
              <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] . "?id=$id"; ?>">
                <div class="form-group">
                  <label for="type">Type:</label>
                  <input type="text" class="form-control" id="type" name="type" required>
                </div>
                <button type="submit" class="btn btn-primary">Add Type</button>
              </form>
            </div>
          </div>

          <!-- Service Type Section -->
          <div class="card">
            <div class="card-header">Service Type</div>
            <div class="card-body">
              <?php
              $sqlServices = "SELECT * FROM types";
              $queryServices = mysqli_query($conn, $sqlServices);
              if ($queryServices) {
                while ($rowServices = mysqli_fetch_assoc($queryServices)) {
                  echo "<p>" . $rowServices['type'] . "</p>";
                }
              } else {
                echo "Error fetching services: " . mysqli_error($conn);
              }
              ?>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</body>
</html>
<?php
} else {
  header("Location: ../Admin");
}
?>
