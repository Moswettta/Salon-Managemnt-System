<?php
include('config.php');
session_start();

$name = '';

if(isset($_SESSION['user'])) {

    // Handle Add Type
    if(isset($_POST['add_type'])) {
        $name = $_POST['name'];

        $sql = "INSERT INTO types (name) VALUES ('$name')";
        if ($conn->query($sql) === TRUE) {
            echo "New type added successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Handle Delete Type
    if(isset($_GET['delete_id'])) {
        $delete_id = $_GET['delete_id'];
        $sql = "DELETE FROM types WHERE type_id='$delete_id'";
        if ($conn->query($sql) === TRUE) {
            echo "Type deleted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Fetch Types
    $types = []; // Initialize types array
    $types_sql = "SELECT * FROM types";
    $types_result = $conn->query($types_sql);
    if (!$types_result) {
        echo "Error fetching types: " . $conn->error;
    } else {
        while($row = $types_result->fetch_assoc()) {
            $types[] = $row;
        }
    }
?>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo htmlspecialchars(TITLE); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
        body {
            font-family: cursive;
            margin: 0;
            padding: 0;
        }
        #header, #headerb {
            font-size: 20px;
            font-weight: bold;
            text-shadow: 2px 2px red;
        }
        #header {
            font-size: 30px;
        }
        .navbar {
            background-color: black;
            color: white;
        }
        .container-fluid {
            padding-left: 0;
            padding-right: 0;
        }
        .service-list {
            margin-top: 20px;
        }
        .service-list li {
            list-style-type: none;
            font-size: 18px;
            margin-bottom: 5px;
        }
        .delete-btn {
            margin-left: 10px;
        }
        .alert {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
        }
        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }
        .sidebar-container {
            padding: 20px;
            background-color: #f5f5f5;
            border-right: 1px solid #ddd;
            min-height: 100vh;
        }
        .main-content {
            padding: 20px;
        }
        .types-container {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <nav class="navbar">
        <div class="navbar-brand" id="header">
            <a href="dashboard.php" style="color: white; text-decoration: none;">Melly's Salon Management System</a>
        </div>
    </nav>
    <div class="row">
        <div class="col-lg-2 sidebar-container">
            <?php include('C:/xampp/htdocs/salon/Admin/sidebar.php'); ?>
        </div>

        <div class="col-lg-10 main-content">
            <h1>Types Management</h1>

            <!-- Add Type Form -->
            <form method="POST" action="">
                <h2>Add Type</h2>
                <div class="form-group">
                    <label for="name">Type Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary" name="add_type">Add Type</button>
            </form>

            <hr>

            <!-- Types List -->
            <div class="types-container">
                <h2>Types List</h2>
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($types as $type) { ?>
                        <tr>
                            <td><?php echo $type['type_id']; ?></td>
                            <td><?php echo htmlspecialchars($type['name']); ?></td>
                            <td>
                                <a href="types.php?delete_id=<?php echo $type['type_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php
} else {
    header("Location: ../Admin");
}
?>
