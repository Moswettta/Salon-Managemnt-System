<?php
include('config.php');
session_start();
if (isset($_SESSION['user'])) {
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title><?php echo TITLE; ?></title>
    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Assets/css/custom.css">
    <style>
    #head {
        font-family: cursive;
        font-size: 20px;
        font-weight: bold;
        text-shadow: 2px 2px red;
    }
    #header {
        font-family: cursive;
        font-size: 30px;
        font-weight: bold;
        text-shadow: 2px 2px red;
    }
    .navbar {
        background-color: black;
        color: white;
        padding-left: 500px;
    }
    </style>
</head>
<body>
<div class="row">
    <nav class="navbar container-fluid">
        <div class="navbar-brand" id="header">
            <a href="dashboard.php" style="color:white;text-decoration:none;">Melly's Salon Management System</a>
        </div>
    </nav>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2" style="margin-left:0px;">
            <?php include('sidebar.php'); ?>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <span id="header">Employee Details</span>
            <?php
            $e = "SELECT * FROM employees";
            $qr = mysqli_query($conn, $e);
            if (mysqli_num_rows($qr) > 0) {
            ?>
            <table class="table table-bordered table-striped" style="color:#2C2D6E;font-family:cursive;font-weight:bold;">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Assigned Clients</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($row = mysqli_fetch_array($qr)) {
                        $firstName = $row['first_name'];
                        $lastName = $row['last_name'];
                        $email = $row['email'];
                        $phone = $row['phone'];
                        $employeeId = $row['id'];

                        // Fetch assigned clients for this employee
                        $assignedClientsQuery = "
                            SELECT u.fname, u.sname 
                            FROM client_employee_allocation cea 
                            JOIN users u ON cea.client_id = u.id 
                            WHERE cea.employee_id = ?";
                        $stmt = $conn->prepare($assignedClientsQuery);
                        if ($stmt === false) {
                            die('Prepare failed: ' . htmlspecialchars($conn->error));
                        }
                        $stmt->bind_param('i', $employeeId);
                        $stmt->execute();
                        $clientsResult = $stmt->get_result();

                        $assignedClients = [];
                        while ($clientRow = $clientsResult->fetch_assoc()) {
                            $assignedClients[] = $clientRow['fname'] . ' ' . $clientRow['sname'];
                        }
                        $assignedClientsList = implode(', ', $assignedClients);
                    ?>
                    <tr>
                        <td><?php echo $firstName; ?></td>
                        <td><?php echo $lastName; ?></td>
                        <td><?php echo $email; ?></td>
                        <td><?php echo $phone; ?></td>
                        <td><?php echo $assignedClientsList; ?></td>
                        <td>
                            <a href="ve.php?view=<?php echo $employeeId; ?>" class="btn btn-sm btn-primary">View Details</a>
                            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" style="display: inline;">
                                <input type="hidden" name="employee_id" value="<?php echo $employeeId; ?>">
                                <button type="submit" class="btn btn-sm btn-danger" name="delete_employee">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
            <?php } else {
                echo "<p>No employees found.</p>";
            } ?>
            
            <!-- Add Employee Section -->
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <h3>Add Employee</h3>
                <input type="text" name="first_name" placeholder="First Name" required>
                <input type="text" name="last_name" placeholder="Last Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="text" name="phone" placeholder="Phone" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" class="btn btn-sm btn-success" name="add_employee">Add Employee</button>
            </form>

            <!-- Allocate Clients to Employees Section -->
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="mt-4">
                <h3>Allocate Client to Employee</h3>
                <div class="form-group">
                    <label for="client_id">Client</label>
                    <select name="client_id" id="client_id" class="form-control" required>
                        <?php
                        $clientQuery = "SELECT id, CONCAT(fname, ' ', sname) AS client_name FROM users WHERE type = 'Customer'";
                        $clientResult = mysqli_query($conn, $clientQuery);
                        while ($client = mysqli_fetch_array($clientResult)) {
                            echo "<option value='{$client['id']}'>{$client['client_name']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="employee_id">Employee</label>
                    <select name="employee_id" id="employee_id" class="form-control" required>
                        <?php
                        $employeeQuery = "SELECT * FROM employees";
                        $employeeResult = mysqli_query($conn, $employeeQuery);
                        while ($employee = mysqli_fetch_array($employeeResult)) {
                            echo "<option value='{$employee['id']}'>{$employee['first_name']} {$employee['last_name']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-sm btn-primary" name="allocate_client">Allocate Client</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>

<?php
if (isset($_POST['delete_employee'])) {
    $employeeId = $_POST['employee_id'];
    $deleteSql = "DELETE FROM employees WHERE id = ?";
    $stmt = $conn->prepare($deleteSql);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param('i', $employeeId);
    if ($stmt->execute()) {
        echo "<script>alert('Employee deleted successfully.');</script>";
        echo "<script>window.location.href = window.location.href;</script>";
    } else {
        echo "<script>alert('Failed to delete employee.');</script>";
    }
}

if (isset($_POST['add_employee'])) {
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $insertSql = "INSERT INTO employees (first_name, last_name, email, phone, password) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertSql);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param('sssss', $firstName, $lastName, $email, $phone, $password);
    if ($stmt->execute()) {
        echo "<script>alert('Employee added successfully.');</script>";
        echo "<script>window.location.href = window.location.href;</script>";
    } else {
        echo "<script>alert('Failed to add employee.');</script>";
    }
}

if (isset($_POST['allocate_client'])) {
    $clientId = $_POST['client_id'];
    $employeeId = $_POST['employee_id'];

    // Allocate the client to the employee
    $allocateSql = "INSERT INTO client_employee_allocation (client_id, employee_id) VALUES (?, ?)";
    $stmt = $conn->prepare($allocateSql);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param('ii', $clientId, $employeeId);
    if ($stmt->execute()) {
        echo "<script>alert('Client allocated to employee successfully.');</script>";
        echo "<script>window.location.href = window.location.href;</script>";
    } else {
        echo "<script>alert('Failed to allocate client.');</script>";
    }
}
} else {
  header("Location: ../Admin");
}
?>
